import random

def random(num1, num2):
    return random(num1, num2)

def round(num):
    return round(num)

def add(num1, num2):
    return num1 + num2

def subtract(num1, num2):
    if num1 > num2:
        return num1 - num2
    else:
        return num2 - num1

def multiply(num1, num2):
    return num1 * num2